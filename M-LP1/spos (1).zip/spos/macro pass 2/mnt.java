public class mnt {
    String name;
    int addr;
    int arg_cnt;

    public mnt(String name, int addr, int arg_cnt) {
        this.name = name;
        this.addr = addr;
        this.arg_cnt = arg_cnt;
    }
}
