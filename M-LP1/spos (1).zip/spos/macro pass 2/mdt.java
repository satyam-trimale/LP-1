public class mdt {
    String stmnt;

    public mdt() {
        this.stmnt = "";
    }
}
