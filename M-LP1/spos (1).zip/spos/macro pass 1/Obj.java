public class Obj {
    public String name;
    public int addr;

    public Obj(String name, int addr) {
        this.name = name;
        this.addr = addr;
    }
}
