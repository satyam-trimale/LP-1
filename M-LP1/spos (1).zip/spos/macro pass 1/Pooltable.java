public class Pooltable {
    public int first;
    public int total_literals;

    public Pooltable(int first, int total_literals) {
        this.first = first;
        this.total_literals = total_literals;
    }
}
